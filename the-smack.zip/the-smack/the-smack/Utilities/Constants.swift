//
//  Constants.swift
//  the-smack
//
//  Created by Rajbir Kaur on 2020-05-19.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import Foundation

typealias CompletionHandler = (_ Success: Bool) ->()
//SEGUES
let TO_LOGIN = "toLogin"
let TO_CREATE_ACCOUNT = "toCreateAccount"
let UNWIND = "unwindToChannel"

//user defaults
let LOGGED_IN_KEY = "loggeIn"
let TOKEN_KEY = "token"
let USER_EMAIL = "userEmail"
