//
//  GradientView.swift
//  the-smack
//
//  Created by Rajbir Kaur on 2020-05-19.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit
@IBDesignable //going to be able to work in the  storyboard
class GradientView: UIView {
    //creating a variable that can be changed inside the storyboard
    @IBInspectable var topColor : UIColor = #colorLiteral(red: 0.2901960784, green: 0.3019607843, blue: 0.8470588235, alpha: 1){
        didSet{
            //setNeedsLayout invalidates the current layout of the receiver and triggers a layout update during the next update cycle
            self.setNeedsLayout()
        }
        
    }
    //going to change inside the storyboard dynamically
    @IBInspectable var bottomColor : UIColor = #colorLiteral(red: 0.1725490196, green: 0.831372549, blue: 0.8470588235, alpha: 1){
        didSet{
            //setNeedsLayout invalidates the current layout of the receiver and triggers a layout update during the next update cycle
            self.setNeedsLayout()
        }
        
    }
    //setNeedsLayout calls a function layoutSubviews
    override func layoutSubviews() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [topColor.cgColor, bottomColor.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        //equals to the size of uiview that it is subclass of
        gradientLayer.frame = self.bounds
        //to insert the gradient layer to UIVIEW
        self.layer.insertSublayer(gradientLayer, at: 0)
    }

}
