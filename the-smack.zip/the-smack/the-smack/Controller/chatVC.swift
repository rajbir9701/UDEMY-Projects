//
//  chatVC.swift
//  the-smack
//
//  Created by Rajbir Kaur on 2020-05-18.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class chatVC: UIViewController {
    //OUTLETS
    
    @IBOutlet weak var menuBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        menuBtn.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)

        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
    }
    


}
