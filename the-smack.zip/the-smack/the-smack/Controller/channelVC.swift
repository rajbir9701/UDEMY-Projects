//
//  channelVC.swift
//  the-smack
//
//  Created by Rajbir Kaur on 2020-05-18.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class channelVC: UIViewController {
    //OUTLETS
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBAction func prepareForUnwind(segue : UIStoryboardSegue){}
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.revealViewController().rearViewRevealWidth = self.view.frame.size.width - 60
    }
    

    @IBAction func loginBtnPressed(_ sender: Any) {
        performSegue(withIdentifier: TO_LOGIN, sender: nil)
    }
    

}
