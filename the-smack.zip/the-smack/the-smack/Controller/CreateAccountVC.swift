//
//  CreateAccountVC.swift
//  the-smack
//
//  Created by Rajbir Kaur on 2020-05-19.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class CreateAccountVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func closePressed(_ sender: Any) {
        performSegue(withIdentifier: UNWIND, sender: nil)
    }
    

}
