//
//  AuthService.swift
//  the-smack
//
//  Created by Rajbir Kaur on 2020-05-21.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//
//login,create user, register user function
//3 VARIABLES TO ACCESS ANYWHERE AND ALSO READING AND WRITING TO AND FROM OUR USER DEFAULTS
import Foundation
import Alamofire
//singleton- accessible globally(there is going to be one instance at a time )
class AuthService{
    //variables stored in user defaults, meaning they are going to be persisted even the user closes the app
    static let instance = AuthService()
    let defaults = UserDefaults.standard
    var isLoggedIn : Bool{
        get{
            return defaults.bool(forKey: LOGGED_IN_KEY)
        }
        set{
            defaults.set(newValue, forKey: LOGGED_IN_KEY)
        }
    }
    var authToken : String{
        get{
            return defaults.value(forKey: TOKEN_KEY) as! String
        }
        set{
            defaults.set(newValue, forKey: TOKEN_KEY)
        }
    }
    var userEmail : String{
        get{
            return defaults.value(forKey: USER_EMAIL) as! String
        }
        set{
            defaults.set(newValue, forKey: USER_EMAIL)
        }
        
    }
    func registerUser(email : String, password : String, copletion: @escaping CompletionHandler){
        let lowercaseEmail = email.lowercased()
        
        //CREATING JSON OBJECTS
        let header = [
            "Content-Type" : "application/json; charset=utf-8"]
        let body : [String: Any] = [
            "email" : lowercaseEmail,
            "password" : password
        ]
        AF.request(URLConvertible as! URLConvertible, method: <#T##HTTPMethod#>, parameters: Parameters?, encoding: ParameterEncoding as! ParameterEncoder as! ParameterEncoding, headers: <#T##HTTPHeaders?#>)
    }
    
}
