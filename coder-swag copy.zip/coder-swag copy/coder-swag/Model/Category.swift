//
//  Category.swift
//  coder-swag
//
//  Created by Rajbir Kaur on 2020-05-11.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import Foundation
struct Category{
    private(set) public var title : String //set privately, but can fetch or get publicly
    private(set) public var imageName : String
    init(title : String, imageName : String) {
        self.title = title
        self.imageName = imageName
    }
}
