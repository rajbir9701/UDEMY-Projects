//
//  CategoryCellTableViewCell.swift
//  coder-swag
//
//  Created by Rajbir Kaur on 2020-05-11.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class CategoryCellTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
