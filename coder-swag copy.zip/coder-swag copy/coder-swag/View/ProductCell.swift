//
//  ProductCell.swift
//  coder-swag
//
//  Created by Rajbir Kaur on 2020-05-12.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class ProductCell: UICollectionViewCell {
    @IBOutlet weak var productImage : UIImageView!
    @IBOutlet weak var productTitle : UILabel!
    @IBOutlet weak var productPrice : UILabel!
    
    func  upadateViews(product : Product) {
        productImage.image = UIImage(named: product.imageName)
        productTitle.text = product.title
        productPrice.text = product.price
        
    }
    
}
